print('''Dear Alice,

Eve's cat has been arrested for second-degree catnapping.

Sincerely,
Bob''')
